# Lava_Cake Recipe 
Today, we are going to prepare delicious lava cakes. Although the chocolates cakes are good but lava cakes are some special molten cakes.

A perfect indulgence for every occasion yet very easy for every day dessert! Classic chocolate lava cake made with five simple ingredients. So decadent, you just can't say no!

### Healthy Fact 
Lava Cakes normally consists of 1270 calories with nearly 72% carbohydrates, 42 % fat and 3% protein. Due to the high calorie present in the cake, Lava Cake is not a suggested dessert for diet watchers.
Due to this health fact, I liked lava cakes more.\

**Recipe Servings: 2**
**Preparation Time: 10 mins**
**Cook/Baking Time: 30 mins**
**Total Cook Time: 40 mins**